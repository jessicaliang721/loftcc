(function($) {
	$(document).foundation();
	console.log($);
})( jQuery );